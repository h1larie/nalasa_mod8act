name = prompt("Please enter your name");
document.getElementById("fname").innerHTML = (name);

username = prompt("Please enter your username");
document.getElementById("username").innerHTML = (username);

gender = confirm("What is your gender?\nPress okay if male\nPress cancel if female")
	if(gender == true){
		alert("Your gender is set to male");
		document.getElementById("gender").innerHTML = "M";
	} else{
		alert("Your gender is set to female");
		document.getElementById("gender").innerHTML = "F";
	}

desc = prompt("Please type a short description of yourself");
document.getElementById("desc").innerHTML = (desc);

BY = prompt("Please enter your birth year");
document.getElementById("year").innerHTML = (BY);
document.getElementById("age").innerHTML = (2023 - BY);


pfp = confirm("Would you like to set a custom profile picture?")
	if(pfp == true){
		pic = prompt("Please enter file name of picture.");
		document.getElementById("ppic").innerHTML = (pic);
	} else{
		alert("Your profile picture has been set to the default.")
	}